"""
shared_utils.py
===============
Shared utilities for all 3 model notebooks:
  - HinglishNormalizer
  - Dataset loading & splitting
  - Tokenization
  - WeightedTrainer
  - Evaluation & metrics
  - XAI (LIME + SHAP + AOPC)
  - Result saving & plotting
"""

import os, re, json, random, warnings, copy
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import torch
from torch import nn
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.metrics import (classification_report, confusion_matrix,
                              f1_score, precision_recall_fscore_support)
from transformers import (AutoTokenizer, AutoModelForSequenceClassification,
                           TrainingArguments, Trainer, EarlyStoppingCallback, set_seed)
from datasets import Dataset as HFDataset, DatasetDict

warnings.filterwarnings('ignore')

# ── Constants ─────────────────────────────────────────────────────────────────
SEED       = 42
MAX_LEN    = 128
BATCH_SIZE = 16
EPOCHS     = 5
LR         = 2e-5
NUM_LABELS = 2
LABEL_MAP  = {0: "Non-Hate", 1: "Hate"}
DEVICE     = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

set_seed(SEED); random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)


# ════════════════════════════════════════════════════════════════════
# 1. NORMALIZATION MODULE
# ════════════════════════════════════════════════════════════════════

SLANG_LEXICON = {
    r'\bbc\b':'bhenchod', r'\bmc\b':'madarchod',
    r'\bbkl\b':'bhosadike', r'\bbsdk\b':'bhosadike',
    r'\bch[ou]tiy[ae]?\b':'chutiya', r'\bchutia\b':'chutiya',
    r'\bsaale?\b':'saala', r'\bkamine[y]?\b':'kamina',
    r'\bkutt[ey]?\b':'kutta', r'\bgand[uu]?\b':'gandu',
    r'\bharami[i]?\b':'harami', r'\bhaaram[ii]?\b':'harami',
    r'\bbhench[o0]d\b':'bhenchod', r'\brandi\b':'randi',
    r'\bnalayak\b':'nalayak', r'\bghati[y]?a\b':'ghatiya',
    r'\bneech\b':'neech', r'\bgawar\b':'gawar',
    r'\bnafrat\b':'nafrat', r'\bdalal\b':'dalal',
    r'\bgaddar\b':'gaddar', r'\bnhi\b':'nahi',
    r'\bnai\b':'nahi', r'\bthk\b':'theek',
    r'\bkl\b':'kal', r'\bkyu\b':'kyun',
    r'\blol\b':'laughing', r'\blmao\b':'laughing hard',
    r'\bhaha+\b':'haha', r'\bwtf\b':'what the hell',
    r'\bstfu\b':'shut up', r'\bomg\b':'oh my god',
}

TRANSLIT_MAP = {
    r'\bkyaa\b':'kya', r'\bnahin\b':'nahi', r'\bnaheen\b':'nahi',
    r'\bbhaut\b':'bahut', r'\bbohat\b':'bahut', r'\bbohot\b':'bahut',
    r'\bbhot\b':'bahut', r'\bterii\b':'teri', r'\bteree\b':'teri',
    r'\bmujhey\b':'mujhe', r'\bmuje\b':'mujhe',
    r'\btumhra\b':'tumhara', r'\byar\b':'yaar',
    r'\bachha\b':'accha', r'\bacha\b':'accha',
}


class HinglishNormalizer:
    """
    Hinglish text normalization pipeline.
    Steps: lowercase → remove URLs/mentions → fix punctuation
           → fix elongation → transliteration unification → slang expansion
    """
    def normalize(self, text: str) -> str:
        t = text.lower().strip()
        t = re.sub(r'http\S+|www\.\S+', '', t)
        t = re.sub(r'@\w+', '[USER]', t)
        t = re.sub(r'#(\w+)', r'\1', t)
        t = re.sub(r'([!?.])\\1{2,}', r'\1', t)
        t = re.sub(r'^rt\s+', '', t)
        t = re.sub(r'(.)\1{2,}', r'\1\1', t)
        for p, v in TRANSLIT_MAP.items():
            t = re.sub(p, v, t, flags=re.IGNORECASE)
        for p, v in SLANG_LEXICON.items():
            t = re.sub(p, v, t, flags=re.IGNORECASE)
        return re.sub(r'\s+', ' ', t).strip()

    def normalize_batch(self, texts):
        return [self.normalize(t) for t in texts]

    def augment_training(self, texts, labels):
        """Create raw+normalized pairs — doubles training data."""
        norm = self.normalize_batch(texts)
        return list(texts) + norm, list(labels) + list(labels)


# ════════════════════════════════════════════════════════════════════
# 2. DATA UTILITIES
# ════════════════════════════════════════════════════════════════════

def load_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, encoding='utf-8', encoding_errors='replace')
    df = df[['text','label']].dropna().reset_index(drop=True)
    df['text']  = df['text'].astype(str)
    df['label'] = df['label'].astype(int)
    return df


def split_train_dev(df: pd.DataFrame, dev_size=0.15):
    tr, dv = train_test_split(df, test_size=dev_size,
                               stratify=df['label'], random_state=SEED)
    return tr.reset_index(drop=True), dv.reset_index(drop=True)


def get_class_weights(df: pd.DataFrame) -> torch.Tensor:
    c = df['label'].value_counts().sort_index().values.astype(float)
    w = 1.0 / c; w = w / w.sum() * len(c)
    return torch.tensor(w, dtype=torch.float)


def tokenize_datasets(df_tr, df_dv, df_te, tokenizer) -> DatasetDict:
    def fn(b):
        return tokenizer(b['text'], truncation=True,
                         padding='max_length', max_length=MAX_LEN)
    ds = DatasetDict({
        'train':      HFDataset.from_pandas(df_tr[['text','label']]),
        'validation': HFDataset.from_pandas(df_dv[['text','label']]),
        'test':       HFDataset.from_pandas(df_te[['text','label']]),
    })
    ds = ds.map(fn, batched=True, remove_columns=['text'])
    ds = ds.rename_column('label', 'labels')
    ds.set_format('torch')
    return ds


# ════════════════════════════════════════════════════════════════════
# 3. TRAINING
# ════════════════════════════════════════════════════════════════════

class WeightedTrainer(Trainer):
    """Handles class imbalance via weighted cross-entropy loss."""
    def __init__(self, cw, *a, **k):
        super().__init__(*a, **k)
        self.cw = cw.to(DEVICE)

    def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
        labels = inputs.pop('labels')
        out    = model(**inputs)
        loss   = nn.CrossEntropyLoss(weight=self.cw)(out.logits, labels)
        return (loss, out) if return_outputs else loss


def compute_metrics(ep):
    p = np.argmax(ep.predictions, axis=-1)
    return {
        'macro_f1':    f1_score(ep.label_ids, p, average='macro'),
        'weighted_f1': f1_score(ep.label_ids, p, average='weighted'),
    }


def get_training_args(output_dir: str) -> TrainingArguments:
    return TrainingArguments(
        output_dir                  = output_dir,
        num_train_epochs            = EPOCHS,
        per_device_train_batch_size = BATCH_SIZE,
        per_device_eval_batch_size  = BATCH_SIZE,
        learning_rate               = LR,
        warmup_steps                = 200,
        weight_decay                = 0.01,
        eval_strategy               = 'epoch',
        save_strategy               = 'epoch',
        load_best_model_at_end      = True,
        metric_for_best_model       = 'macro_f1',
        greater_is_better           = True,
        fp16                        = torch.cuda.is_available(),
        logging_steps               = 50,
        seed                        = SEED,
        report_to                   = 'none',
        save_total_limit            = 1,
    )


def train_model(model_name: str, df_train: pd.DataFrame,
                df_dev: pd.DataFrame, df_test: pd.DataFrame,
                output_dir: str):
    """
    Fine-tune a pretrained model and evaluate on one test set.
    Returns: dict with metrics + saved model path.
    """
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model     = AutoModelForSequenceClassification.from_pretrained(
                    model_name, num_labels=NUM_LABELS)
    ds  = tokenize_datasets(df_train, df_dev, df_test, tokenizer)
    cw  = get_class_weights(df_train)
    args = get_training_args(output_dir)

    trainer = WeightedTrainer(
        cw, model=model, args=args,
        train_dataset  = ds['train'],
        eval_dataset   = ds['validation'],
        compute_metrics= compute_metrics,
        callbacks      = [EarlyStoppingCallback(early_stopping_patience=2)],
    )
    trainer.train()

    out   = trainer.predict(ds['test'])
    preds = np.argmax(out.predictions, axis=-1)
    true  = out.label_ids
    rpt   = classification_report(true, preds,
                target_names=list(LABEL_MAP.values()), output_dict=True)

    save_path = f"{output_dir}/best_model"
    trainer.save_model(save_path); tokenizer.save_pretrained(save_path)

    return {
        'macro_f1':    round(rpt['macro avg']['f1-score'], 4),
        'weighted_f1': round(rpt['weighted avg']['f1-score'], 4),
        'precision':   round(rpt['macro avg']['precision'], 4),
        'recall':      round(rpt['macro avg']['recall'], 4),
        'preds': preds, 'true': true,
        'model': model, 'tokenizer': tokenizer,
        'model_path': save_path,
        'report_str': classification_report(true, preds,
                          target_names=list(LABEL_MAP.values())),
    }


# ════════════════════════════════════════════════════════════════════
# 4. MULTI-DATASET EVALUATION
# ════════════════════════════════════════════════════════════════════

def evaluate_on_dataset(model, tokenizer, df_test: pd.DataFrame,
                         dataset_name: str) -> dict:
    """Zero-shot evaluation on any test set (Hindi / English / Combined)."""
    model.eval()
    preds_list = []
    for text in df_test['text'].tolist():
        enc = tokenizer(text, return_tensors='pt', truncation=True,
                        padding=True, max_length=MAX_LEN).to(DEVICE)
        with torch.no_grad():
            logits = model(**enc).logits
        preds_list.append(torch.argmax(logits).item())

    true  = df_test['label'].tolist()
    macro = f1_score(true, preds_list, average='macro')
    rpt   = classification_report(true, preds_list,
                target_names=list(LABEL_MAP.values()), output_dict=True)

    print(f"\n  [{dataset_name}] Macro F1: {macro:.4f}")
    print(classification_report(true, preds_list,
              target_names=list(LABEL_MAP.values())))

    return {
        'dataset':     dataset_name,
        'macro_f1':    round(macro, 4),
        'weighted_f1': round(rpt['weighted avg']['f1-score'], 4),
        'precision':   round(rpt['macro avg']['precision'], 4),
        'recall':      round(rpt['macro avg']['recall'], 4),
        'preds': np.array(preds_list),
        'true':  np.array(true),
    }


# ════════════════════════════════════════════════════════════════════
# 5. XAI — LIME + SHAP + AOPC
# ════════════════════════════════════════════════════════════════════

def build_predict_fn(model, tokenizer):
    """Returns probability-outputting predict function for LIME/SHAP."""
    def predict_proba(texts):
        model.eval()
        all_p = []
        for i in range(0, len(texts), 8):
            enc = tokenizer(list(texts[i:i+8]), return_tensors='pt',
                            truncation=True, padding=True,
                            max_length=MAX_LEN).to(DEVICE)
            with torch.no_grad():
                logits = model(**enc).logits
            all_p.extend(torch.softmax(logits, -1).cpu().numpy())
        return np.array(all_p)
    return predict_proba


def run_lime(predict_fn, texts: list, label_names: list,
             n_features=8, n_samples=200) -> list:
    """Run LIME on a list of texts. Returns list of explanation dicts."""
    try:
        from lime.lime_text import LimeTextExplainer
    except ImportError:
        print("pip install lime"); return []

    exp = LimeTextExplainer(class_names=label_names)
    results = []
    for text in texts:
        try:
            e = exp.explain_instance(text, predict_fn,
                                     num_features=n_features,
                                     num_samples=n_samples)
            results.append({
                'text': text,
                'predicted': label_names[np.argmax(predict_fn([text])[0])],
                'features': e.as_list(),
            })
        except Exception as ex:
            print(f"LIME error: {ex}")
    return results


def compute_aopc(texts: list, predict_fn, n_steps=5) -> float:
    """AOPC faithfulness metric. Higher = more faithful explanations."""
    drops = []
    for text in texts:
        tokens = text.split()
        if len(tokens) < 3: continue
        orig = predict_fn([text])[0].max()
        step = max(1, len(tokens) // n_steps)
        cum = 0.0; rem = tokens.copy()
        for _ in range(n_steps):
            if not rem: break
            rem = rem[:-step]
            mp = predict_fn([' '.join(rem) if rem else '[MASK]'])[0].max()
            cum += float(orig - mp)
        drops.append(cum / n_steps)
    return float(np.mean(drops)) if drops else 0.0


def xai_comparison(model, tokenizer, normalizer: HinglishNormalizer,
                   test_texts: list, output_dir: str,
                   dataset_name: str, n_examples=5):
    """
    Full XAI analysis for one test set:
      1. LIME on raw vs normalized examples
      2. AOPC faithfulness comparison
      3. Save plots
    """
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    predict_fn  = build_predict_fn(model, tokenizer)
    label_names = list(LABEL_MAP.values())
    norm_texts  = normalizer.normalize_batch(test_texts[:n_examples])

    raw_exps  = run_lime(predict_fn, test_texts[:n_examples], label_names)
    norm_exps = run_lime(predict_fn, norm_texts, label_names)

    # Print comparison
    print(f"\n  XAI — {dataset_name}: RAW vs NORMALIZED")
    print("  " + "="*55)
    for i, (r, n) in enumerate(zip(raw_exps[:3], norm_exps[:3])):
        print(f"  [{i+1}] RAW : {r['text'][:60]}")
        print(f"       NORM: {norm_texts[i][:60]}")
        print(f"       Pred(raw):{r['predicted']} | Pred(norm):{n['predicted']}")
        rt = sorted(r['features'], key=lambda x: abs(x[1]), reverse=True)[:3]
        nt = sorted(n['features'], key=lambda x: abs(x[1]), reverse=True)[:3]
        print(f"       Top RAW tokens : {[(f,round(w,3)) for f,w in rt]}")
        print(f"       Top NORM tokens: {[(f,round(w,3)) for f,w in nt]}")

    # AOPC
    aopc_raw  = compute_aopc(test_texts[:20],       predict_fn)
    aopc_norm = compute_aopc(norm_texts[:20], predict_fn)
    print(f"\n  AOPC Raw: {aopc_raw:.4f} | AOPC Norm: {aopc_norm:.4f} | Δ={aopc_norm-aopc_raw:+.4f}")

    # LIME bar plot
    if raw_exps and norm_exps:
        _plot_lime_bars(raw_exps[:3], norm_exps[:3],
                        test_texts[:3], norm_texts[:3],
                        output_dir, dataset_name)

    # AOPC bar chart
    _plot_aopc(aopc_raw, aopc_norm, output_dir, dataset_name)

    return {'aopc_raw': aopc_raw, 'aopc_norm': aopc_norm,
            'lime_raw': raw_exps, 'lime_norm': norm_exps}


def _plot_lime_bars(raw_exps, norm_exps, raw_texts, norm_texts,
                    output_dir, dataset_name):
    n = len(raw_exps)
    fig, axes = plt.subplots(n, 2, figsize=(14, n * 3.2))
    if n == 1: axes = axes.reshape(1, -1)
    for i in range(n):
        for j, (feats, title_text) in enumerate([
            (raw_exps[i]['features'],  f"RAW\n{raw_texts[i][:45]}"),
            (norm_exps[i]['features'], f"NORM\n{norm_texts[i][:45]}"),
        ]):
            top    = sorted(feats, key=lambda x: abs(x[1]), reverse=True)[:6]
            tokens = [t[0] for t in top]
            wts    = [t[1] for t in top]
            colors = ['#E24B4A' if w > 0 else '#378ADD' for w in wts]
            ax = axes[i][j]
            ax.barh(tokens, wts, color=colors)
            ax.axvline(0, color='gray', linewidth=0.5)
            ax.set_title(title_text, fontsize=9)
            ax.set_xlabel('LIME weight', fontsize=8)
            ax.tick_params(labelsize=8)
    r = mpatches.Patch(color='#E24B4A', label='→ Hate')
    b = mpatches.Patch(color='#378ADD', label='→ Non-Hate')
    fig.legend(handles=[r, b], loc='upper right', fontsize=9)
    plt.suptitle(f'LIME Attribution — {dataset_name}', fontsize=12)
    plt.tight_layout()
    plt.savefig(f"{output_dir}/lime_{dataset_name}.png", dpi=150, bbox_inches='tight')
    plt.close()


def _plot_aopc(aopc_raw, aopc_norm, output_dir, dataset_name):
    fig, ax = plt.subplots(figsize=(5, 4))
    bars = ax.bar(['Raw', 'Normalized'], [aopc_raw, aopc_norm],
                  color=['#B5D4F4', '#185FA5'], width=0.4)
    for bar, v in zip(bars, [aopc_raw, aopc_norm]):
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + .001,
                f'{v:.4f}', ha='center', fontweight='bold', fontsize=10)
    ax.set_ylabel('AOPC Score')
    ax.set_title(f'XAI Faithfulness — {dataset_name}')
    ax.grid(axis='y', alpha=0.3)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    plt.tight_layout()
    plt.savefig(f"{output_dir}/aopc_{dataset_name}.png", dpi=150)
    plt.close()


# ════════════════════════════════════════════════════════════════════
# 6. PLOTTING & REPORTING
# ════════════════════════════════════════════════════════════════════

def plot_confusion_matrix(true, preds, dataset_name, output_dir):
    cm = confusion_matrix(true, preds)
    fig, ax = plt.subplots(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
                xticklabels=list(LABEL_MAP.values()),
                yticklabels=list(LABEL_MAP.values()))
    ax.set_title(f'Confusion Matrix — {dataset_name}')
    ax.set_xlabel('Predicted'); ax.set_ylabel('True')
    plt.tight_layout()
    plt.savefig(f"{output_dir}/cm_{dataset_name}.png", dpi=150)
    plt.close()


def plot_multi_dataset_f1(results_list: list, model_name: str, output_dir: str):
    """Bar chart comparing Macro F1 across all 3 test datasets."""
    names  = [r['dataset'] for r in results_list]
    scores = [r['macro_f1'] for r in results_list]
    colors = ['#534AB7', '#0F6E56', '#993C1D']
    fig, ax = plt.subplots(figsize=(8, 5))
    bars = ax.bar(names, scores, color=colors[:len(names)], width=0.5)
    for bar, v in zip(bars, scores):
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + .005,
                f'{v:.4f}', ha='center', fontweight='bold', fontsize=11)
    ax.set_ylabel('Macro F1 Score', fontsize=12)
    ax.set_title(f'{model_name} — Transfer to 3 Test Sets', fontsize=13)
    ax.set_ylim(0, min(1.0, max(scores) + 0.1))
    ax.grid(axis='y', alpha=0.3)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    plt.tight_layout()
    plt.savefig(f"{output_dir}/f1_comparison_{model_name}.png", dpi=150)
    plt.close()
    print(f"  Saved F1 comparison chart.")


def save_results_table(results_list: list, model_name: str, output_dir: str):
    df = pd.DataFrame(results_list)[['dataset','macro_f1','weighted_f1','precision','recall']]
    df.to_csv(f"{output_dir}/results_{model_name}.csv", index=False)
    print(f"\n{'='*60}")
    print(f"  {model_name} — RESULTS TABLE")
    print(f"{'='*60}")
    print(df.to_string(index=False))
    print(f"{'='*60}")
    return df
